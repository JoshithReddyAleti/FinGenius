import React, { useState } from "react";
import { getChatbotResponse } from "./api"; 
import Header from "./Header";
import Footer from "./Footer";
import "./Chatbot.css";

const Chatbot = () => {
    const [query, setQuery] = useState("");
    const [response, setResponse] = useState(""); 
    const [image, setImage] = useState(null);
    const [executionTime, setExecutionTime] = useState("");  
    const [conversation, setConversation] = useState([]);  // Stores chat history

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!query.trim()) return;

        // Store user query in chat history
        const userMessage = { role: "user", text: query };
        setConversation((prev) => [...prev, userMessage]);

        const userQuery = query;
        setQuery(""); // Clear input after sending

        try {
            const res = await getChatbotResponse(userQuery);

            if (res.data.text) {
                setResponse(res.data.text);  // Store main response
                const botMessage = { role: "bot", text: res.data.text };
                setConversation((prev) => [...prev, botMessage]);
            }

            if (res.data.image) {
                setImage(`data:image/png;base64,${res.data.image}`);  // Convert Base64 to inline image
                const botMessage = { role: "bot", image: `data:image/png;base64,${res.data.image}` };
                setConversation((prev) => [...prev, botMessage]);
            }

            if (res.data.execution_time) {
                setExecutionTime(res.data.execution_time);  // Track response time
            }
        } catch (err) {
            const errorMessage = { role: "bot", text: "Sorry, something went wrong." };
            setConversation((prev) => [...prev, errorMessage]);
        }
    };

    return (
        <>
            <Header />
            <div className="chatbot-container">
                <h2>Financial Chatbot</h2>

                <div className="chat-history">
                    {conversation.length === 0 && <p>Start the conversation by typing a message.</p>}
                    {conversation.map((msg, index) => (
                        <div key={index} className={`chat-message ${msg.role}`}>
                            <strong>{msg.role === "user" ? "You: " : "Bot: "}</strong> 
                            {msg.text && <span dangerouslySetInnerHTML={{ __html: msg.text }} />}
                            {msg.image && <img src={msg.image} alt="Trend Analysis" />}
                        </div>
                    ))}
                </div>

                <form onSubmit={handleSubmit} className="chat-input-form">
                    <input
                        type="text"
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        placeholder="Type your message here..."
                    />
                    <button type="submit">Send</button>
                </form>

                {executionTime && <p className="execution-time"><b>Response Time:</b> {executionTime}</p>}
            </div>
            <Footer />
        </>
    );
}

export default Chatbot;