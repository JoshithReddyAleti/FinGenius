from retriever import retrieve_relevant_data
from generator import generate_response

def chatbot(query):
    retrieved_data = retrieve_relevant_data(query)
    response = generate_response(query, retrieved_data)
    return response