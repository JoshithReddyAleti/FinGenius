import openai
import json
import matplotlib
import matplotlib.pyplot as plt
import io
import base64
import re
from flask import send_file
from utils.config import OPENAI_API_KEY

# Set Matplotlib to "headless" mode to prevent pop-ups
matplotlib.use('Agg')

openai.api_key = OPENAI_API_KEY

def generate_response(query, retrieved_data):
    """
    Generates financial insights, ensuring graphs are properly rendered as Base64
    images and returned in API responses instead of opening in a pop-up.
    """

    # Identify if a graph is needed
    graph_type = None
    if "bar" in query.lower():
        graph_type = "bar"
    elif "pie" in query.lower():
        graph_type = "pie"
    elif "line" in query.lower() or "trend" in query.lower():
        graph_type = "line"
    elif "scatter" in query.lower():
        graph_type = "scatter"

    # Prepare prompt for OpenAI
    prompt = f"""
    You are a financial assistant. Provide your response in **HTML format** for better UI rendering.

    - Use **bold** text (`<b>`) for key numbers and categories.
    - Use **paragraphs (`<p>`)** for explanations.
    - Avoid **bullet list (`<ul>`) and table (`<table>`).**
    - If relevant, **use headings (`<h3>`)** for readability.
    - Provide spending insights with suggestions if needed.

    Answer the user's query concisely, without unnecessary data:
    {query}

    {f"Also, generate Python Matplotlib code to create a {graph_type} chart for spending trends." if graph_type else ""}
    """

    response = openai.ChatCompletion.create(
        model="gpt-4-turbo",
        messages=[
            {"role": "system", "content": "You are a financial assistant. Provide HTML-formatted insights and generate Python Matplotlib code for spending trends if explicitly requested."},
            {"role": "user", "content": prompt}
        ]
    )

    # Extract AI-generated response text
    ai_text_response = response.choices[0].message["content"]
    cleaned_text_response = re.sub(r"```python.*?```", "", ai_text_response, flags=re.DOTALL).strip()

    # Default to no image
    image_base64 = None  

    # Execute AI-generated Matplotlib Code only if a graph is requested
    if graph_type and "```python" in ai_text_response:
        try:
            # Extract Python code from AI response
            python_code = ai_text_response.split("```python")[1].split("```")[0]
            print("\nGenerated Python Code:\n", python_code)  # Debugging step

            # Execute the code in a safe context
            exec(python_code, globals())

            # Save the generated Matplotlib graph as an image in memory
            img = io.BytesIO()
            plt.savefig(img, format='png', bbox_inches="tight")
            img.seek(0)

            # Convert the image to Base64
            image_base64 = base64.b64encode(img.getvalue()).decode("utf-8")

            # Close the figure to avoid memory issues
            plt.close()

        except Exception as e:
            print(f"Error executing AI-generated code: {e}")

    return {
        "text": cleaned_text_response,  # Properly formatted HTML
        "image": image_base64  # Image as Base64 (if graph requested)
    }  
