import os
from dotenv import load_dotenv

DB_CONFIG = {
    "HOST": "localhost",
    "USER": "root",
    "PASSWORD": "root",
    "DATABASE": "transactions2"
}

# Load environment variables from .env file
load_dotenv()

# Access the API key securely
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")