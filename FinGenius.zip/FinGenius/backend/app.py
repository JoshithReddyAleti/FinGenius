import time
from flask import Flask, request, jsonify
from flask import send_file, make_response
from flask_cors import CORS
from chatbot import chatbot

app = Flask(__name__)
CORS(app)

@app.route('/chatbot', methods=['POST'])
def chatbot_endpoint():
    query = request.json.get("query", "")
    
    start_time = time.time() 
    response = chatbot(query)
    end_time = time.time() 

    execution_time = round(end_time - start_time, 2)

    # If there's an image, send both text + Base64 image
    if response["image"]:
        return jsonify({
            "text": response["text"],
            "image": response["image"],
            "execution_time": f"{execution_time} seconds"
        })
    
    # Otherwise, return text only
    return jsonify({"text": response["text"]})

if __name__ == "__main__":
    app.run(debug=True)
