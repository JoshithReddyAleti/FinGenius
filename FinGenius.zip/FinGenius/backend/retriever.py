import pandas as pd
import re
import spacy
from db_connection import get_db_connection
from datetime import datetime

nlp = spacy.load("en_core_web_sm")

def extract_time_period(query):
    time_units = {"day": "DAY", "days": "DAY", "month": "MONTH", "months": "MONTH", "year": "YEAR", "years": "YEAR"}
    match = re.search(r'(\d+)\s*(day|days|month|months|year|years)', query.lower())
    return (int(match.group(1)), time_units[match.group(2)]) if match else (None, None)

def get_unique_categories_and_merchants():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT DISTINCT category FROM transactions")
    categories = [row[0].lower() for row in cursor.fetchall()]
    cursor.execute("SELECT DISTINCT merchant_name FROM transactions")
    merchants = [row[0].lower() for row in cursor.fetchall()]
    conn.close()
    return categories, merchants

def extract_category_or_merchant(query):
    categories, merchants = get_unique_categories_and_merchants()
    tokens = query.lower().split()
    return next((cat for cat in categories if cat in tokens), None), next((merch for merch in merchants if merch in tokens), None)

def retrieve_relevant_data(query):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)  # Ensure SQL results are dictionaries

    category_filter, merchant_filter = extract_category_or_merchant(query)
    time_value, time_unit = extract_time_period(query)

    query_string = "SELECT date, merchant_name, category, amount FROM transactions WHERE 1=1"
    params = []

    if category_filter:
        query_string += " AND category = %s"
        params.append(category_filter.title())

    if merchant_filter:
        query_string += " AND merchant_name = %s"
        params.append(merchant_filter.title())

    if time_value and time_unit:
        query_string += f" AND date >= DATE_SUB(NOW(), INTERVAL %s {time_unit})"
        params.append(time_value)

    query_string += " ORDER BY date DESC"
    cursor.execute(query_string, params)
    rows = cursor.fetchall()  # Now returns list of dictionaries

    conn.close()

    # Convert SQL datetime and decimal types to JSON serializable formats
    for row in rows:
        row["amount"] = float(row["amount"])  # Convert Decimal to Float
        if isinstance(row["date"], datetime):  # Only apply isoformat() if it's a datetime
            row["date"] = row["date"].isoformat()

    return rows  # Now JSON-serializable